
import os, zipfile, requests

def check_and_apply_update():
    url = "https://github.com/m1wa1111/Cel-update/raw/main/update.zip"
    local_path = "update.zip"

    try:
        response = requests.get(url)
        with open(local_path, "wb") as f:
            f.write(response.content)

        with zipfile.ZipFile(local_path, 'r') as zip_ref:
            zip_ref.extractall(".")
        os.remove(local_path)
        print("Обновление успешно установлено!")
    except Exception as e:
        print(f"Ошибка при обновлении: {e}")
