
from modules.voice import speak
from modules.brain import respond_to

def start_cell():
    speak("Привет, я CEL. Чем могу помочь?")
    while True:
        user_input = input("Вы: ")
        response = respond_to(user_input)
        speak(response)
