
import pyttsx3

engine = pyttsx3.init()
engine.setProperty('rate', 175)
engine.setProperty('voice', 'com.apple.speech.synthesis.voice.milena')  # Windows: IVONA, Microsoft

def speak(text):
    print(f"CEL: {text}")
    engine.say(text)
    engine.runAndWait()
