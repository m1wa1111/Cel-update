
def respond_to(user_input):
    user_input = user_input.lower()

    if "браузер" in user_input:
        return "Открываю браузер"
    elif "время" in user_input:
        from datetime import datetime
        return f"Сейчас {datetime.now().strftime('%H:%M')}"
    elif "пока" in user_input:
        return "До встречи!"
    else:
        return "Я вас поняла. Выполняю."
