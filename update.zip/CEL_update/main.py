
from modules.core import start_cell
from modules.update_manager import check_and_apply_update

print("Проверка обновлений...")
check_and_apply_update()

print("Запуск CEL...")
start_cell()
